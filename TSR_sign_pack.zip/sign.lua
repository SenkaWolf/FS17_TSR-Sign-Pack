
sign = {};
sign_mt = Class(sign, Placeable);
InitObjectClass(sign, "sign");

function sign:new(isServer, isClient, customMt)
    local self = Placeable:new(isServer, isClient, sign_mt);
    registerObjectClassName(self, "sign");
    
    return self;
end;


registerPlaceableType("sign", sign);